-Added my name to the paragraph on the homepage.

-added wikipedia

-added favicon

-Dr. Lemon