    button {
      background-color: blue;
      color: black;
      transition: background-color 2s, color 5s;
    }

    button:hover {
      background-color: black;
      color: white;
    }